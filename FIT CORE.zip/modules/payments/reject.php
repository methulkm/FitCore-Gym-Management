<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_role(['admin']);

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare('SELECT p.*, m.full_name FROM payments p JOIN members m ON m.member_id = p.member_id WHERE payment_id = ?');
$stmt->execute([$id]);
$payment = $stmt->fetch();
if (!$payment) redirect_with_flash('modules/payments/index.php', 'error', 'Payment not found.');
if ($payment['status'] !== 'pending') redirect_with_flash('modules/payments/index.php', 'error', 'This payment has already been processed.');

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify('modules/payments/index.php');
    $reason = trim($_POST['reason'] ?? '');
    v_push($errors, v_required($reason, 'Rejection reason'));
    v_push($errors, v_free_text($reason, 'Rejection reason', 255, 5));

    if (!$errors) {
        $pdo->prepare('UPDATE payments SET status = "rejected", rejection_reason = ?, verified_by = ?, verified_at = NOW() WHERE payment_id = ? AND status = "pending"')
            ->execute([$reason, current_user()['user_id'], $id]);
        redirect_with_flash('modules/payments/index.php', 'success', "Payment {$payment['payment_code']} rejected.");
    }
}

$pageTitle = 'Reject Payment';
$activeNav = 'payment-verification';
require __DIR__ . '/../../includes/layout_start.php';
?>
<div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 max-w-lg">
  <?php foreach ($errors as $err): ?>
    <div class="rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-sm font-medium px-4 py-3 mb-4"><?= e($err) ?></div>
  <?php endforeach; ?>
  <p class="text-sm text-slate-600 mb-4">Rejecting payment <b><?= e($payment['payment_code']) ?></b> from <b><?= e($payment['full_name']) ?></b>.</p>
  <form method="post">
    <?= csrf_field() ?>
    <label class="text-xs font-bold text-slate-500">Reason (e.g. unclear slip, incorrect amount, payment not found)</label>
    <textarea name="reason" rows="3" maxlength="255" minlength="5" class="mt-1 w-full border border-slate-200 rounded-[10px] px-3.5 py-2.5 text-sm" required><?= e(old('reason')) ?></textarea>
    <div class="flex gap-3 pt-4">
      <button type="submit" class="bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-[10px] px-5 py-2.5 text-sm">Confirm Reject</button>
      <?= btn('Cancel', base_url('modules/payments/index.php'), 'ghost') ?>
    </div>
  </form>
</div>
<?php require __DIR__ . '/../../includes/layout_end.php'; ?>
